create
  definer = root@localhost procedure getNewestEvent()
BEGIN
  SELECT *
  FROM event
  WHERE enabled = 1
    AND id =
        (SELECT MAX(id) FROM event);
END;

