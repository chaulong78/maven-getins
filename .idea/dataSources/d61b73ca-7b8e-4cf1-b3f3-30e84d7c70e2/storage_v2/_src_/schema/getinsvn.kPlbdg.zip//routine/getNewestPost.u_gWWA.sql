create
  definer = root@localhost procedure getNewestPost()
BEGIN
  SELECT * FROM post ORDER BY id DESC LIMIT 3;
END;

